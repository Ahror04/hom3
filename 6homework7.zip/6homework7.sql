drop table category;
create table category (
	id INT,
	first_name VARCHAR(50),
	product_count INT
);
insert into category (id, first_name, product_count) values (1, '', 75);
insert into category (id, first_name, product_count) values (2, '', 77);
insert into category (id, first_name, product_count) values (3, '', 5);
insert into category (id, first_name, product_count) values (5, '', 36);
insert into category (id, first_name, product_count) values (4, '', 95);

drop table product;
create table product (
	id serial primary key,
	title VARCHAR(50),
	qty INT,
	price INT,
	color VARCHAR(50),
	category INT,
	foreign key (category) references category(id)
);
insert into product (id, title, qty, price, color, category) values (1, '', 122, 581, '', 697);
insert into product (id, title, qty, price, color, category) values (2, '', 796, 744, '', 986);
insert into product (id, title, qty, price, color, category) values (3, '', 874, 276, '', 456);
insert into product (id, title, qty, price, color, category) values (4, '', 369, 34, '', 9);
insert into product (id, title, qty, price, color, category) values (5, '', 675, 632, '', 974);

create table users (
	id INT,
	first_name VARCHAR(50),
	reg_date varchar(50)
);
insert into users (id, first_name, reg_date) values (1, '', '2/28/2024');
insert into users (id, first_name, reg_date) values (2, '', '2/15/2024');
insert into users (id, first_name, reg_date) values (3, '', '2/2/2024');
insert into users (id, first_name, reg_date) values (4, '', '12/25/2023');
insert into users (id, first_name, reg_date) values (5, '', '3/11/2024');

create table cart (
	id INT,
	user_id INT,
	total_qty INT,
	total_summa INT,
	add_date varchar(50),
foreign key (users) references users(id)     
);
insert into cart (id, user_id, total_qty, total_summa, add_date) values (1, 73, 40, 35, '8/12/2023');
insert into cart (id, user_id, total_qty, total_summa, add_date) values (2, 83, 59, 93, '4/17/2024');
insert into cart (id, user_id, total_qty, total_summa, add_date) values (3, 9, 26, 79, '12/16/2023');
insert into cart (id, user_id, total_qty, total_summa, add_date) values (4, 27, 37, 36, '12/9/2023');
insert into cart (id, user_id, total_qty, total_summa, add_date) values (5, 54, 38, 8, '1/3/2024');

create table cart_detail (
	id INT,
	cart_id INT,
	qty INT,
	total_summa INT,
	add_date varchar(50),
	product_id INT,
foreign key (cart) references cart(id),
foreign key (product) references product(id)
);
insert into cart_detail (id, cart_id, qty, total_summa, add_date, product_id) values (1, 68, 65, 63, '9/17/2023', 37);
insert into cart_detail (id, cart_id, qty, total_summa, add_date, product_id) values (2, 39, 80, 86, '8/23/2023', 73);
insert into cart_detail (id, cart_id, qty, total_summa, add_date, product_id) values (3, 78, 100, 22, '8/2/2023', 38);
insert into cart_detail (id, cart_id, qty, total_summa, add_date, product_id) values (4, 55, 37, 32, '10/15/2023', 39);
insert into cart_detail (id, cart_id, qty, total_summa, add_date, product_id) values (5, 69, 40, 2, '5/30/2023', 59);

create table comment (
	id INT,
	users_id INT,
	text VARCHAR(50),
	reg_date varchar(50),
	product_id INT,
foreign key (users) references users(id), 
foreign key (product) references product(id)
);
insert into comment (id, users_id, text, reg_date, product_id) values (1, 87, '', '10/5/2023', 53);
insert into comment (id, users_id, text, reg_date, product_id) values (2, 4, '', '7/1/2023', 74);
insert into comment (id, users_id, text, reg_date, product_id) values (3, 34, '', '1/27/2024', 3);
insert into comment (id, users_id, text, reg_date, product_id) values (4, 29, '', '5/13/2024', 41);
insert into comment (id, users_id, text, reg_date, product_id) values (5, 95, '', '12/31/2023', 34);

select * from product where title like 'A%';
select from product where price>100;
select from product where price between 150 and 450 order by price;
select*from product order by qty asc ; --osish
select*from product where color='blue' order by qty ;

